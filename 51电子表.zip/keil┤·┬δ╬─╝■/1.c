#include<reg51.h>
#define uChar unsigned char
#define uInt unsigned int
uChar a[]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f};    //单个数码管字模
uChar b[]={0xfe,0xfd,0xfb,0xf7,0xef,0xdf,0xbf,0x7f};              //选通数码管位数
uChar second=00,minute=00,hour=12,count;                          //赋初始值
sbit one = P3^0;                                                  // 调节位
sbit two = P3^1;                                                  //加一位
sbit three = P3^2;                                                //减一位
sbit four= P3^3;                                                  //暂停位
sbit five= P1^0;                                                  //LED状态位
void Delay(unsigned int t)                            //时间延时函数
{
	int i,x;
	for(i=1;i<=x;x++);
while(t)
	{
		t--;
	}
}
void Dispaly1(uChar second,uChar minute,uChar hour)   //数码管显示函数
{
	P2=b[0];              //小时的显示
	P0=a[hour/10];        //小时的十位显示
	Delay(10);
	P2=b[1];
	P0=a[hour%10];        //小时的个位显示
	Delay(10);
	
	P2=b[2];              //--显示
	P0=0x40; 
	Delay(10);
	
	P2=b[3];              //分钟显示
	P0=a[minute/10];   
	Delay(10);
	
	P2=b[4];
	P0=a[minute%10]; 
	Delay(10);
	
	P2=b[5]; 
	P0=0x40; 
	Delay(10);
	
	P2=b[6];             //秒钟显示
	P0=a[second/10];    
	Delay(10);
	
	P2=b[7];; 
	P0=a[second%10]; 
	Delay(10);
}

void Keyscan1()      //调节函数
{
	static uChar i=0,j=0;   //定义初始值，以I,J分别实现暂停和调节功能 i是暂停位次数，j是调节标志位
	if(four==0)        //暂停键按下
		{
			while(!four);
			i++;
		}
		if(i%2==1)
			{
				TR0=0;     //关中断  停止计时
			}
			if(i%2==0)
				{
					TR0=1;  //开中断
				}
				if(one==0){     //当按下第一个键位
					while(!one);
					j++; 
				}
					if(j%3==1)    //j+1使进入到分钟的调节
						{
							if(two==0)
								{
									while(!two);
									minute++;
									if(minute==60)        //判断进位
										minute=0; 
								}
							if(three==0)
								{
									while(!three);
									
									if(minute==0)          //判断退位标志
										minute=60; 
                  minute--;
								}
						}
						if(j%3==2)  //进入到小时的调节
							{
								if(two==0)
									{ 
										while(!two);
										hour++;
										if(hour==24)
											hour=0; 
									}
								if(three==0)
									{ 
										while(!three);
										hour--;
										if(hour==0)
											hour=24; 
									}
							}
}

void main()   //主函数
{	void delay(int);
	int time = 50;
	TMOD=0x01; 	  //TO定时方式一
	TH0=(65536-10000)/256;  //高位值  定义10ms
	TL0=(65536-10000)%256;  //低位值
	EA=1;    //开总中断
	ET0=1;   //开TO中断
	TR0=1;   //启动TO
	while(1)
		{
			static uChar h=0;
			five=!five;
			delay(time);
			Dispaly1(second,minute,hour);  //函数初始化
			Keyscan1();    //函数初始化
		}
}

void time0_int(void) interrupt 1   //中断函数 循环进位
{
	TH0=(65536-10000)/256;
	TL0=(65536-10000)%256;
	count++;
	if(count==100)                // 一秒
		{
			count=0;
			second++;
			if(second==60)            //一分钟
				{
					second=0;
					minute++;
					if(minute==60)        //一小时
						{
							minute=0;
							hour++;
							if(hour==24)      //24小时
								{
									hour=0;
								}
						}
				}
		}
}